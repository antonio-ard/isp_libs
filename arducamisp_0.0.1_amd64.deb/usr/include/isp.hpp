#pragma once
#include "common.hpp"

namespace Arducam {
class ISP {
public:
    virtual ~ISP() = default;
    virtual void queueBuffer(cv::Mat img) = 0;
    virtual cv::Mat getBuffer(int timeout = 1500) = 0;
    Signal<int(std::string name, int64_t val)> writeCtrl;
};
ISP *CreateISP(std::string filename, CameraInfo info, StatisticsMode statisMode);
}