#pragma once

#include "Semaphore.hpp"
#include "Signal.hpp"
#include <iostream>
#include <memory>
#include <string.h>
#include <stdint.h>
#include <opencv2/opencv.hpp>

#ifdef __linux__
#include <arpa/inet.h>
#endif

#ifdef _WIN32
#include <winsock.h>
#pragma comment (lib, "ws2_32.lib")
#endif



#ifdef __cplusplus
extern "C" {
#endif

typedef enum Order {
    BGGR = 0,
    GBRG = 1,
    GRBG = 2,
    RGGB = 3
} BayerOrder;

struct CameraInfo {
    BayerOrder order;
	// bit depth of the raw camera output
	uint32_t bitdepth;
	// size in pixels of frames in this mode
	uint16_t width, height;
	// size of full resolution uncropped frame ("sensor frame")
	uint16_t sensor_width, sensor_height;
	// binning factor (1 = no binning, 2 = 2-pixel binning etc.)
	uint8_t bin_x, bin_y;
	// location of top left pixel in the sensor frame
	uint16_t crop_x, crop_y;
	// scaling factor (so if uncropped, width*scale_x is sensor_width)
	double scale_x, scale_y;
	// scaling of the noise compared to the native sensor mode
	double noise_factor;
	// line time in nanoseconds
	double line_length;
	// any camera transform *not* reflected already in the camera tuning
	uint32_t transform;
};

#ifdef __cplusplus
}
#endif
namespace Arducam {

	enum class  StatisticsMode {
		HARDWARE_MODE,
		SOFTWARE_MODE,
	};

}